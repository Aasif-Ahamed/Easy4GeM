<?php
ob_start();
session_start();
include 'config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
//Load Composer's autoloader
require 'vendor/autoload.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | EROT Stones</title>
    <?php
    include 'btrpcss.php';
    ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.css" />
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.js"></script>
    <script>
        $(document).ready(function() {
            $('#myTableA').DataTable({
                scrollX: true,
            });
        });
    </script>
    <style>
        html,
        body {
            width: 100%;
        }
    </style>
</head>

<body>
    <?php
    include 'navbar.php';
    if (isset($_POST['btnInsertNew'])) {
        $targetDir = "ownuploads/";
        $emailOwners = $_POST['emailOwners'];
        $itemdesc = $_POST['itemdesc'];
        $norh = $_POST['norh'];
        $carrat = $_POST['carrat'];
        $buyer = $_POST['buyer'];
        $dos = $_POST['dos'];
        $dop = $_POST['dop'];
        $nod = $_POST['nod'];
        $soldval = $_POST['soldval'];
        $commislbl = $_POST['commislbl'];
        $rectype = 'own';
        $paymentdate = date('Y-m-d', strtotime($dos . ' + ' . $nod . 'days'));
        echo $paymentdate;

        $n = 10;
        function getName($n)
        {
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $randomString = '';

            for ($i = 0; $i < $n; $i++) {
                $index = rand(0, strlen($characters) - 1);
                $randomString .= $characters[$index];
            }

            return $randomString;
        }

        if (isset($_FILES['itempic']) && $_FILES['itempic']['error'] == 0) {
            $fileName = getName($n) . $buyer . basename($_FILES['itempic']['name']);
            echo $fileName;
            $targetFilePath = $targetDir . $fileName;
            $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
            /*             $allowTypes = array('jpg', 'png', 'jpeg', 'JPG', 'PNG', 'JPEG');
            if (in_array($fileType, $allowTypes)) { */
            if (move_uploaded_file($_FILES["itempic"]["tmp_name"], $targetFilePath)) {
                $insertmtdt = "INSERT INTO `masterdata`(`rectype`,`description`, `nat_heat`, `carrat`, `buyer`, `email`,  `dataofsell`, `noofdays`, `dateofpay`, `soldvalue`, `picture`,`comments`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
                $stmt = $connection->prepare($insertmtdt);
                $stmt->bind_param('ssssssssssss', $rectype, $itemdesc, $norh, $carrat, $buyer, $emailOwners, $dos, $nod, $paymentdate, $soldval, $fileName, $commislbl);
                if ($stmt->execute()) {
                    echo 'Records Saved Successfully';
                    header("Location:dashboardB.php");
                } else {
                    echo 'Error ' . $insertmtdt . '<br>' . $connection->error;
                }
                $stmt->close();
            } else {
                echo 'Error Uploading The File';
            }
            /* } else {
                echo 'Blocked Type';
            } */
        } else {
            echo 'Error At L1';
        }
    }
    ?>
    <h1 class="text-center">OWN STONES <i class="fa-solid fa-gem"></i></h1>
    <br>
    <div class="row mb-3 d-flex justify-content-center text-center" style="width: 100%;">
        <div class="col-md-12">
            <button type="button" name="createNewA" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa-solid fa-plus"></i> New Record</button>
            <button type="submit" onclick="window.location.href='dashboard.php';" class="btn btn-outline-primary">Dashboard</button>
        </div>
    </div>
    <table class="table table-striped-columns display" id="myTableA">
        <thead>
            <tr>
                <th style="display: none;">#</th>
                <th style="text-align: center; width:100%;">#</th>
                <th>Description</th>
                <th>N/H</th>
                <th><i class="fa-solid fa-carrot" style="color: #ff9500;"></i></th>
                <th>Purchase Value</th>
                <th>Buyer</th>
                <th>Date of Sell</th>
                <th>No of Days</th>
                <th>Date of Pay</th>
                <th>Sold Value</th>
                <th><i class="fa-solid fa-image"></i></th>
                <th>Comments</th>
            </tr>
        </thead>
        <?php
        $mdquery = "SELECT * FROM `masterdata` WHERE `rectype`='own'";
        $mdqueryres = $connection->query($mdquery);
        if ($mdqueryres->num_rows > 0) {
            while ($mdrow = $mdqueryres->fetch_assoc()) {
        ?>
                <tbody>
                    <tr>
                        <td style="display: none;"><?php echo $mdrow['id'] ?></td>
                        <td style="text-align: center; width:100%;">
                            <form action="" method="post">
                                <?php
                                if ($mdrow['paystatus'] == 'Pending') {
                                ?>
                                    <button type="submit" class="btn btn-warning btn-sm" name="updateErot" value="<?php echo $mdrow['id']; ?>"><i class="fa-solid fa-circle-check"></i></button>
                                <?php
                                }
                                ?>
                                <button type="button" class="btn btn-sm btn-secondary" data-bs-toggle="modal" data-bs-target="#exampleModalEmail" data-bs-whatever="<?php echo $mdrow['id']; ?>"><i class="fa-solid fa-envelope"></i></button>
                                <a href="delrec.php?aorb=b&vmxc=<?php echo $mdrow['id']; ?>&reqtype=rmv&imgpth=<?php echo 'erotuploads/' . $mdrow['picture']; ?>" name="btnDeleteRec" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></a>
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#invoiceModal" id-val="<?php echo $mdrow['id']; ?>">
                                    <i class="fa-solid fa-file-invoice"></i>
                                </button>
                            </form>
                        </td>
                        <td><?php echo $mdrow['description'] ?></td>
                        <td><?php echo $mdrow['nat_heat'] ?></td>
                        <td><?php echo $mdrow['carrat'] ?></td>
                        <td><?php echo $mdrow['purcvalue'] ?></td>
                        <td><?php echo $mdrow['buyer'] ?></td>
                        <td>
                            <?php
                            echo $mdrow['dataofsell'] ?></td>
                        <td>
                            <?php

                            echo $mdrow['noofdays'];

                            ?>
                        </td>
                        <td><?php echo $mdrow['dateofpay'] ?></td>
                        <td><?php echo $mdrow['soldvalue'] ?></td>
                        <td>
                            <?php
                            if ($mdrow['picture'] == 'N/A') {
                                echo '<i class="fa-solid fa-circle-exclamation" style="color: #ff0000;" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Image Not Available"></i>';
                            } else {
                            ?>
                                <a class="btn btn-sm btn-primary" href="erotuploads/<?php echo $mdrow['picture'] ?>" target="_blank"><i class="fa-solid fa-eye"></i></a>
                            <?php
                            }

                            ?>
                        </td>
                        <td><?php echo $mdrow['comments']; ?></td>
                    </tr>
                </tbody>
        <?php
            }
        }
        ?>
    </table>
    <div class="modal fade" id="invoiceModal" tabindex="-1" aria-labelledby="exampleModalLabel2" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title mdtitle fs-5" id="exampleModalLabel2">Generate Invoice</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body modalbody">
                    <form id="profileform" action="invoice.php" method="post">
                        <div class="row">

                            <input type="hidden" name="idvalue" value="">
                            <div class="col-md-6">
                                <button type="submit" formtarget="_blank" name="buyerown" class="btn btn-primary btn-sm w-100">Customer Invoice</button>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        $('#invoiceModal').on('show.bs.modal', function(e) {
            var opener = e.relatedTarget; //this holds the element who called the modal
            var firstname = $(opener).attr('id-val');
            $('#profileform').find('[name="idvalue"]').val(firstname);

        });
    </script>
    <!-- Email Modal -->
    <div class="modal fade modal-lg" id="exampleModalEmail" aria-labelledby="exampleModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5">Confirmation Required</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" method="post">
                        <input type="hidden" name="idval" class="form-control" id="recipient-name">
                        <p>You are about to send a reminder email. Kindly confirm this activity to proceed</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="btnSendMail" class="btn btn-primary">Send Reminder</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- END -->
    <!-- Email Modal Script -->
    <script>
        const exampleModal = document.getElementById('exampleModalEmail')
        if (exampleModal) {
            exampleModal.addEventListener('show.bs.modal', event => {
                // Button that triggered the modal
                const button = event.relatedTarget
                // Extract info from data-bs-* attributes
                const recipient = button.getAttribute('data-bs-whatever')
                // If necessary, you could initiate an Ajax request here
                // and then do the updating in a callback.

                // Update the modal's content.
                const modalTitle = exampleModal.querySelector('.modal-title')
                const modalBodyInput = exampleModal.querySelector('.modal-body input')

                //modalTitle.textContent = `New message to ${recipient}`
                modalBodyInput.value = recipient
            })
        }
    </script>
    <!-- END -->
    <!-- MAIL CODE -->
    <?php
    if (isset($_POST['btnSendMail'])) {
        $mail = new PHPMailer(true);
        $idval = $_POST['idval'];
        $querymail = "SELECT * FROM `masterdata` WHERE `id`=$idval";
        $querymailres = $connection->query($querymail);
        if ($querymailres->num_rows > 0) {
            while ($randRow = $querymailres->fetch_assoc()) {
                $buyername = $randRow['buyer'];
                $buyeremail = $randRow['email'];
                $daysleft = $randRow['noofdays'];
                $buydesc = $randRow['description'];
                $buyersoldvalue = $randRow['soldvalue'];
                try {
                    $mail->setFrom('asifnawasdeen@gmail.com', 'Aasif Ahamed');
                    $mail->addAddress($buyeremail, $buyername);     //Add a recipient
                    $mail->addReplyTo('asifnawasdeen@gmail.com', 'Aasif Ahamed');
                    $mail->isHTML(true);                                  //Set email format to HTML
                    $mail->Subject = 'Payment Reminder';
                    $mail->Body    = 'Dear ' . $buyername . ',<br>

                    This is a friendly reminder about an outstanding payment on your purchase of ' . $buydesc . ' is due in another ' . $daysleft . ' days. <br><br>
                    

                    Total Amount: Rs. ' . $buyersoldvalue . '<br><br>
                    
                    Your prompt attention to this matter is appreciated. Please let us know if you have any questions.<br><br>
                    
                    Best regards,<br>
                    
                    [Your Name]
                    [Your Company Name]';
                    //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

                    $mail->send();
                    echo 'Message has been sent';
                } catch (Exception $e) {
                    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                }
            }
        }
    }
    ?>
    <!-- END MAIL CODE -->
    <!-- Create New Modal -->
    <!-- New Rec PHP Code-->
    <?php

    ?>
    <!-- END -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Create A New Record</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-md-12 mb-2">
                                <input type="file" name="itempic" class="form-control">
                            </div>
                            <div class="col-md-12 mb-2">
                                <div class="form-floating">
                                    <textarea class="form-control" name="itemdesc" placeholder="Item Description" id="floatingTextarea3" style="height: 100px"></textarea>
                                    <label for="floatingTextarea3">Item Description</label>
                                </div>
                            </div>
                            <div class="col-md-6 mb-2">
                                <div class="form-floating">
                                    <select class="form-select" name="norh" id="floatingSelect" aria-label="Floating label select example">
                                        <option value="Natural">Natural</option>
                                        <option value="Heat">Heat</option>
                                    </select>
                                    <label for="floatingSelect">Natural / Heat</label>
                                </div>
                            </div>
                            <div class="col-md-6 mb-2">
                                <div class="form-floating">
                                    <input type="text" class="form-control" name="carrat" id="carratlabel" placeholder="Carrat">
                                    <label for="carratlabel">Carrat</label>
                                </div>
                            </div>
                            <div class="col-md-6 mb-2">
                                <div class="form-floating">
                                    <input type="text" class="form-control" name="owner" id="ownerLabel" placeholder="Text">
                                    <label for="ownerLabel">Purchase Value</label>
                                </div>
                            </div>
                            <div class="col-md-6 mb-2">
                                <div class="form-floating">
                                    <input type="text" class="form-control" name="buyer" id="buyerLabel" placeholder="Text">
                                    <label for="buyerLabel">Buyer</label>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating mb-3">
                                    <input type="email" name="emailOwners" class="form-control" id="emailOwner" placeholder="name@example.com">
                                    <label for="emailOwner">Buyer Email</label>
                                </div>
                            </div>
                            <div class="col-md-12 mb-2">
                                <div class="input-group mb-3">
                                    <span class="input-group-text">Date Of Sell</span>
                                    <input type="date" name="dos" class="form-control" id="floatingInputGroup1" placeholder="Date Of Sell" value="<?php echo date('Y-m-d') ?>">
                                </div>
                            </div>
                            <div class="col-md-6 mb-2">
                                <div class="form-floating">
                                    <input type="number" name="nod" class="form-control" id="nodLabel" placeholder="Text">
                                    <label for="nodLabel">No of Days</label>
                                </div>
                            </div>
                            <div class="col-md-6 mb-2">
                                <div class="form-floating">
                                    <input type="number" class="form-control" name="soldval" id="soldvalLabel" placeholder="Text">
                                    <label for="soldvalLabel">Sold Value</label>
                                </div>
                            </div>
                            <div class="col-md-12 mb-2">
                                <div class="form-floating">
                                    <textarea class="form-control" name="commislbl" placeholder="Leave a comment here" id="floatingTextarea" style="height: 150px;"></textarea>
                                    <label for="floatingTextarea">Comments</label>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" name="btnInsertNew" class="btn btn-primary">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>

    <?php include 'btrpjs.php'; ?>
</body>

</html>